SELECT 
    date,
    datetime,
    sct.cash_type_id,
    card,
    money,
    scn.coffee_name_id
FROM food.raw.coffee_sales
LEFT JOIN {{ ref('stg_cash_type') }} sct USING (cash_type)
LEFT JOIN {{ ref('stg_coffee_name') }} scn USING (coffee_name)

