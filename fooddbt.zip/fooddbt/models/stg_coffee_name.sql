{{ config(materialized='view') }}

WITH ordered_data AS (
    SELECT 
        coffee_name,
        ROW_NUMBER() OVER (ORDER BY LOWER(TRIM(coffee_name))) AS coffee_name_id
    FROM {{ source('food_raw', 'coffee_sales') }}
    GROUP BY coffee_name
)

SELECT 
    coffee_name_id,
    coffee_name
FROM ordered_data