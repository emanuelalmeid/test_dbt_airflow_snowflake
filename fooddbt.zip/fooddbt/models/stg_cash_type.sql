{{ config(materialized='view') }}

WITH ordered_data AS (
    SELECT 
        cash_type,
        ROW_NUMBER() OVER (ORDER BY LOWER(TRIM(cash_type))) AS cash_type_id
    FROM {{ source('food_raw', 'coffee_sales') }}
    GROUP BY cash_type
)

SELECT 
    cash_type_id,
    cash_type
FROM ordered_data
