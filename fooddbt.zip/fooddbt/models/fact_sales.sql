{{ config(materialized='table') }}

WITH sales AS (
    SELECT 
        date,
        datetime,
        sct.cash_type_id,
        card,
        money,
        scn.coffee_name_id
    FROM {{ source('food_raw', 'coffee_sales') }}
    LEFT JOIN {{ ref('stg_cash_type') }} sct USING (cash_type)
    LEFT JOIN {{ ref('stg_coffee_name') }} scn USING (coffee_name)
)

SELECT * FROM sales
